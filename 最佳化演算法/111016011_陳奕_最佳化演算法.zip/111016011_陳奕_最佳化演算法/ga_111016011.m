clc; clear; close all;

%% 參數設定
pop_size = 100;    % 族群大小
gen_max = 100;     % 最大世代數
crossover_rate = 0.8;  % 交配率
mutation_rate = 0.02;  % 突變率

x1_bits = 18;      % x1 需要的位元數
x2_bits = 15;      % x2 需要的位元數
total_bits = x1_bits + x2_bits; % 個體長度

x1_min = -3.0; x1_max = 12.1;
x2_min = 4.1; x2_max = 5.8;

%% 初始化族群
population = randi([0, 1], pop_size, total_bits); 

%% 主循環
best_fitness = zeros(1, gen_max);
for gen = 1:gen_max
    [x1, x2] = decode(population, x1_bits, x2_bits, x1_min, x1_max, x2_min, x2_max);
    fitness = fitness_function(x1, x2);
    best_fitness(gen) = max(fitness);    % save
    new_population = selection(population, fitness);
    new_population = crossover(new_population, crossover_rate);    % 交配
    new_population = mutation(new_population, mutation_rate);    % 突變
   
    population = new_population;
end

%% result
[x1_best, x2_best] = decode(population, x1_bits, x2_bits, x1_min, x1_max, x2_min, x2_max);
fitness = fitness_function(x1_best, x2_best);
[best_value, idx] = max(fitness);
best_x1 = x1_best(idx);
best_x2 = x2_best(idx);

fprintf("最佳解: x1 = %.5f, x2 = %.5f, f(x1, x2) = %.5f\n", best_x1, best_x2, best_value);

% 畫圖
figure;
plot(1:gen_max, best_fitness, 'b', 'LineWidth', 2);
xlabel('世代數');
ylabel('最佳適應度');
title('遺傳演算法收斂曲線');
grid on;

%% fit
function f = fitness_function(x1, x2)
    f = 21.5 + x1 .* sin(4 * pi * x1) + x2 .* sin(20 * pi * x2);
end

%% decode
function [x1, x2] = decode(population, x1_bits, x2_bits, x1_min, x1_max, x2_min, x2_max)
    x1_bin = population(:, 1:x1_bits);
    x2_bin = population(:, x1_bits+1:end);
    
    x1_dec = sum(x1_bin .* 2.^((x1_bits-1):-1:0), 2); % 手動轉換 x1
    x2_dec = sum(x2_bin .* 2.^((x2_bits-1):-1:0), 2); % 手動轉換 x2
    
    % 映射到範圍內
    x1 = x1_min + x1_dec * ((x1_max - x1_min) / (2^x1_bits - 1));
    x2 = x2_min + x2_dec * ((x2_max - x2_min) / (2^x2_bits - 1));
end


%% selected
function selected_population = selection(population, fitness)
    total_fitness = sum(fitness);
    prob = fitness / total_fitness;
    cum_prob = cumsum(prob);
    
    selected_population = zeros(size(population));
    for i = 1:size(population, 1)
        r = rand;
        idx = find(cum_prob >= r, 1, 'first');
        selected_population(i, :) = population(idx, :);
    end
end

%% 交配
function new_population = crossover(population, crossover_rate)
    [pop_size, total_bits] = size(population);
    new_population = population;
    
    for i = 1:2:pop_size-1
        if rand < crossover_rate
            crossover_point = randi([1, total_bits-1]);
            new_population(i, crossover_point+1:end) = population(i+1, crossover_point+1:end);
            new_population(i+1, crossover_point+1:end) = population(i, crossover_point+1:end);
        end
    end
end

%% 突變
function new_population = mutation(population, mutation_rate)
    [pop_size, total_bits] = size(population);
    new_population = population;
    
    for i = 1:pop_size
        for j = 1:total_bits
            if rand < mutation_rate
                new_population(i, j) = 1 - new_population(i, j);
            end
        end
    end
end
