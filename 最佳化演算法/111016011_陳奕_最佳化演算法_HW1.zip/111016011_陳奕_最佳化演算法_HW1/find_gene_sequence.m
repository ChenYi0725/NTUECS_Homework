function find_gene_sequence()

    chromosome = input('Enter a Chromosome string: ', 's');
    
    start_codon = 'ATG'; 
    stop_codons = {'TAA', 'TAG', 'TGA'}; 
    genes = {}; % 找到的序列

    % 找到所有 ATG 的位置
    start_positions = strfind(chromosome, start_codon);

    for i = 1:length(start_positions)
        start_idx = start_positions(i);

        % 搜尋終止碼 且 是3倍數距離
        for j = start_idx+3:3:length(chromosome)-2
            codon = chromosome(j:j+2); % 取3個字母
            if any(strcmp(codon, stop_codons))
                genes{end+1} = chromosome(start_idx+3:j-1); % 擷取
                break;
            end
        end
    end

    % 輸出
    if isempty(genes)
        disp('no gene is found');
    else
        for i = 1:length(genes)
            disp(genes{i});
        end
    end
end
