clear; clc;

%% 參數設定
pop_size = 100;               % 數量
chrom_length = 20;           % 變數長度x10 + y10
x_bits = 10;
y_bits = 10;
pc = 0.65;                    % 交配率
pm = 0.01;                   % 突變率
max_gen = 100;               % 最大世代數
xmin = -1.5; xmax = 4;
ymin = -3;   ymax = 4;

%% init
pop = randi([0 1], pop_size, chrom_length);

%% 紀錄
best_fitness = zeros(1, max_gen);


for gen = 1:max_gen
    % 解碼
    [x, y] = decode(pop, xmin, xmax, ymin, ymax, x_bits, y_bits);
    
    
    fitness = (x - y).^2 - x + 2.*y + sin(x + y) + 1; % 適應值
    
    % best 適應值
    [min_fitness, idx] = min(fitness);
    best_fitness(gen) = min_fitness;
    
    
    fprintf('第 %d 代: 最佳值 = %.5f (x=%.4f, y=%.4f)\n', ...
        gen, min_fitness, x(idx), y(idx));
    
    % 輪盤法
    fitness_inv = 1 ./ (fitness + 1e-6);
    prob = fitness_inv / sum(fitness_inv);
    cum_prob = cumsum(prob);
    new_pop = zeros(size(pop));
    for i = 1:pop_size
        r = rand;
        idx = find(cum_prob >= r, 1, 'first');
        new_pop(i,:) = pop(idx,:);
    end
    
    % 單點交配
    for i = 1:2:pop_size
        if rand < pc
            cp = randi([1 chrom_length-1]); % 交配點
            temp = new_pop(i, cp+1:end);
            new_pop(i, cp+1:end) = new_pop(i+1, cp+1:end);
            new_pop(i+1, cp+1:end) = temp;
        end
    end
    
    % 突變
    for i = 1:pop_size
        for j = 1:chrom_length
            if rand < pm
                new_pop(i,j) = 1 - new_pop(i,j);
            end
        end
    end
    
    % 更新族群
    pop = new_pop;
end

%% 畫圖
figure;
plot(1:max_gen, best_fitness, 'LineWidth', 2);
xlabel('世代數');
ylabel('最佳適應值');
title('基因演算法收斂過程');
grid on;


function [x, y] = decode(pop, xmin, xmax, ymin, ymax, x_bits, y_bits)
    % decode x
    x_bin = pop(:, 1:x_bits);
    x_dec = zeros(size(x_bin, 1), 1);
    for i = 1:x_bits
        x_dec = x_dec + x_bin(:,i) * 2^(x_bits - i);
    end
    x = xmin + (xmax - xmin) * x_dec / (2^x_bits - 1);
    x = round(x, 4); %後4位
    
    % decode y
    y_bin = pop(:, x_bits+1:x_bits+y_bits);
    y_dec = zeros(size(y_bin, 1), 1);
    for i = 1:y_bits
        y_dec = y_dec + y_bin(:,i) * 2^(y_bits - i);
    end
    y = ymin + (ymax - ymin) * y_dec / (2^y_bits - 1);
    y = round(y, 4); 
end