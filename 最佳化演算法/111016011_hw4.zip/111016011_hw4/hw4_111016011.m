clc; clear;

numParticles = 30;
maxIter = 200;
w = 0.7;         % 慣性
c1 = 1.5;        % 自己
c2 = 1.5;        % 群體

xMin = -1.5; xMax = 4;
yMin = -3;   yMax = 3;
dim = 2;

vMax = 0.5;
vMin = -0.5;

fitness = @(x, y) sin(x + y) + (x - y).^2 - 1.5 .* x + 2.5 .* y + 1;

% init pos & vel
position = [xMin + (xMax - xMin) * rand(numParticles, 1), ...
            yMin + (yMax - yMin) * rand(numParticles, 1)];
velocity = zeros(numParticles, dim);

pBest = position;
pBestFit = fitness(position(:,1), position(:,2));
[gBestFit, idx] = min(pBestFit);
gBest = pBest(idx, :);

gBestHistory = zeros(maxIter, 1);

% main loop
for t = 1:maxIter
    for i = 1:numParticles
        r1 = rand(); r2 = rand();
        
        % vel 更新
        velocity(i,:) = w * velocity(i,:) ...
            + c1 * r1 * (pBest(i,:) - position(i,:)) ...
            + c2 * r2 * (gBest - position(i,:));
        
        % 限制 v
        velocity(i,:) = max(min(velocity(i,:), vMax), vMin);
        
        % pos 更新
        position(i,:) = position(i,:) + velocity(i,:);
        
        % 限制 pos
        position(i,1) = max(min(position(i,1), xMax), xMin);
        position(i,2) = max(min(position(i,2), yMax), yMin);
        
        % fit
        fit = fitness(position(i,1), position(i,2));
        
        % 個體最佳
        if fit < pBestFit(i)
            pBest(i,:) = position(i,:);
            pBestFit(i) = fit;
        end
        
        % 全域最佳
        if fit < gBestFit
            gBest = position(i,:);
            gBestFit = fit;
        end
    end
    gBestHistory(t) = gBestFit;
end

% 輸出
xBest = round(gBest(1), 3);
yBest = round(gBest(2), 3);
fBest = round(gBestFit, 4);

fprintf('最佳解：x = %.3f, y = %.3f\n', xBest, yBest);
fprintf('最小值 f(x, y) = %.4f\n', fBest);

% 圖
figure;
plot(gBestHistory, 'LineWidth', 2);
xlabel('Iteration');
ylabel('Best Fitness Value');
title('PSO 收斂圖');
grid on;
